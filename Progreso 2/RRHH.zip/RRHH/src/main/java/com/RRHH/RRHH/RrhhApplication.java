package com.RRHH.RRHH;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RrhhApplication {

	public static void main(String[] args) {
		SpringApplication.run(RrhhApplication.class, args);
	}

}
